Next
====

Presses "Play Next" on Udacity and Udemy


Available on the Chrome Web Store:

[Next](https://chrome.google.com/webstore/detail/next/ohbainpmaikiicdjgnbpcekhlmdigopi)


To install from a local git clone, see the instructions here:

https://developer.chrome.com/extensions/getstarted#unpacked